// Abrir y cerrar los modales
document.getElementById('btn-login').addEventListener('click', function() {
    document.getElementById('modal-login').style.display = 'flex';
});

document.getElementById('btn-suscribirse').addEventListener('click', function() {
    document.getElementById('modal-suscribirse').style.display = 'flex';
});

document.querySelectorAll('.close').forEach(function(closeBtn) {
    closeBtn.addEventListener('click', function() {
        closeBtn.parentElement.parentElement.style.display = 'none';
    });
});

// Cerrar modal al hacer clic fuera del contenido
window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
});
